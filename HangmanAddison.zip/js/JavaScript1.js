//return an number between 0 and 2
function randomNumber(array){
	Rand = Math.floor(Math.random() * array.length);
    return Rand;
}