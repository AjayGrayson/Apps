function setCharAt(str,index,chr) {
    if(index > str.length-1){ return str;}
    return str.substr(0,index) + chr + str.substr(index+1);
}