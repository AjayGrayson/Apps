function findGuessLoc(str,letter){
	var tempArray = [];
    var x = str.length;
    x = x -1;
	for(var i = 0; i <= x; i++){
        
        if(str[i]=== letter){
            tempArray.push(i);
        }
        
    }
    return tempArray;
}