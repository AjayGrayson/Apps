/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "Foods": {
        "type": "array",
        "items": {
            "type": "string"
        }
    },
    "Animals": {
        "type": "array",
        "items": {
            "type": "string"
        }
    },
    "Number": {
        "type": "number"
    },
    "Boolean": {
        "type": "boolean"
    },
    "States": {
        "type": "array",
        "items": {
            "type": "string"
        }
    },
    "Cars": {
        "type": "array",
        "items": {
            "type": "string"
        }
    },
    "String": {
        "type": "string"
    },
    "Movies": {
        "type": "array",
        "items": {
            "type": "string"
        }
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "Animals": new $a.SessionStorage("Animals", "Animals"),

    "Cars": new $a.SessionStorage("Cars", "Cars"),

    "Foods": new $a.SessionStorage("Foods", "Foods"),

    "States": new $a.SessionStorage("States", "States"),

    "Answer": new $a.SessionStorage("Answer", "String"),

    "Movies": new $a.SessionStorage("Movies", "Movies"),

    "Stars": new $a.SessionStorage("Stars", "String"),

    "Guess": new $a.SessionStorage("Guess", "String"),

    "numOfWrongs": new $a.SessionStorage("numOfWrongs", "Number"),

    "Categories": new $a.SessionStorage("Categories", "String"),

    "wrongLetters": new $a.SessionStorage("wrongLetters", "String")
};