function finishEquation(){
tempVar= Apperyio.storage.input1.get();
temp= Apperyio.storage.input2.get();
if(tempVar === ""){
  Apperyio.storage.input1.set(0);
}
else{
       Apperyio.storage.input1.set(tempVar);  
    }
if(temp === ""){
  Apperyio.storage.input2.set(0);
}
  else{
       Apperyio.storage.input2.set(temp); 
  }
}